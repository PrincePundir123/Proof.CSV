# ProofCSV

A question in. A result you can prove.

ProofCSV is a web application for the Vultr Agent Rush CSV Analyst challenge. Upload a CSV, ask a question, and inspect real executed charts, cleaned files, Python code, logs, and artifact hashes. Generated code runs only inside a disposable sandbox; there is no host-execution fallback.

## Current status

The implementation, automated tests, submission copy, cover, and slide deck are prepared. Docker is installed in Ubuntu WSL on this development machine. Real container tests passed for chart execution, memory/CPU/PID limits, network/filesystem boundaries, timeout, fresh workspaces and verified cleanup. A local AI mode supports development without a cloud API key. No Vultr account, server, inference key, public deployment, public GitHub repository, or final recorded demo has been configured. Unit and regular browser tests use clearly identified test doubles; real Docker and local workflow checks are separate.

The complete local workflow passed using the actual Qwen3.5 model and Docker: all six monthly totals in the exported CSV, the displayed PNG, the total revenue metric, downloadable artifact hashes, whitespace trimming, duplicate removal with missing values preserved, and both Safety Lab tests. `START-LOCAL.bat` and `STOP-LOCAL.bat` were also verified. Evidence and a screenshot are saved in the ignored `runtime/local-verification` directory. A Docker heartbeat keeps WSL awake through long model calls.

The event runs November 3–8, 2026. This repository was prepared before kickoff. Confirm the event's policy on prior code before using it as your submission, and disclose what was prepared beforehand. The accessible event page permits preparation but does not define the full prior-work policy.

## Run the complete local app

On this Windows computer, double-click `START-LOCAL.bat` and open http://localhost:3000. The launcher starts the local Qwen model and Node app, and checks Docker in Ubuntu WSL. `.env` selects local AI. No API key is needed. Upload a CSV, enter a question, and click **Run analysis**. See [local setup and verification](docs/LOCAL_RUN.md).

Local AI is a development option. The hackathon deployment must use Vultr hosting and Vultr Serverless Inference. The local model/runtime downloads are excluded from Git and the source archive.

## Run the sample preview

Requires Node.js 22 or later. Runtime has no npm dependencies.

```powershell
npm.cmd start
```

Open http://localhost:3000. With no `.env` configuration, this starts in preview mode. Click **Explore a sample report** to inspect the product. The sample totals are computed from the bundled CSV using fixed server code, without an AI call or sandbox run. The UI and exports identify it as a sample. Arbitrary questions are disabled until real execution is configured. `npm start` uses `.env` when present; launch the local model first for local AI mode.

On Windows, you can also double-click `START-PREVIEW.bat`. A portable source archive is available as `proofcsv-project.zip` after running `python scripts/package.py`.

On Linux/macOS, use `npm start`. Stop with Ctrl+C.

## Enable real execution

1. Install Docker, preferably rootless Docker with cgroup v2 and working resource controls.
2. Build the trusted image: `docker build -t proofcsv-sandbox:1 sandbox`.
3. Copy `.env.example` to `.env`. Set `VULTR_SERVERLESS_INFERENCE_API_KEY` and `VULTR_MODEL` locally. Never commit this file or paste your key into chat.
   For public Vultr deployment, keep `MODEL_PROVIDER=vultr` and `DOCKER_TRANSPORT=native`.
4. Choose a currently available coding-capable model from https://api.vultrinference.com/v1/models. All planning, repairs, and explanation calls use the fixed https://api.vultrinference.com/v1/chat/completions endpoint.
5. Run `npm run test:sandbox`. It must pass before you claim real containment or record the hackathon demo.
6. Restart the app and run the sample through **Run analysis**. This performs real inference and container execution, unlike **Explore a sample report**.

See [the Vultr deployment guide](docs/DEPLOYMENT.md) for HTTPS, service configuration, credits, and deployment verification.

## Architecture

```mermaid
flowchart LR
  User[Public browser] --> App[Node.js backend on Vultr VM]
  App --> LLM[Vultr Serverless Inference]
  LLM --> App
  App --> Box[Disposable offline Docker container on Vultr]
  Box --> Results[Actual files and logs]
  Results --> App
  App --> User
```

The VM is the control layer: it validates uploads, plans with Vultr Inference, dispatches Python into a fresh sandbox, verifies output, optionally repairs one failed execution, and explains the result. The sandbox receives only the CSV, code, and public execution settings. It receives no API key, credentials, app environment, host mount, or Docker socket.

Per-run boundary: nonroot user, read-only root filesystem, no network, dropped Linux capabilities, `no-new-privileges`, 256 MB memory, 0.5 CPU, 64 processes, bounded output, and writable temporary filesystems. The runner terminates the task's process group on completion or timeout. Every attempt is followed by forced container removal and an independent inspection verifying absence. Unverified cleanup disables further execution until operator intervention. Optional `SANDBOX_RUNTIME=runsc` supports an installed gVisor runtime.

Application protections: same-origin JSON writes, HttpOnly SameSite session cookies, owner-scoped uploads/reports, bounded CSV parsing, limited concurrent jobs, hourly session limits, a global daily inference-call allowance, supported-file validation, SHA-256 verification, and automatic retention. Reports and uploads are held in memory and expire after 60 minutes by default. Restarting the backend removes report history. Sample exports are separately identified. The daily call allowance also resets on restart, so use a Vultr billing limit as the external budget control.

Docker shares the host kernel. These controls are not a claim of immunity to kernel or runtime vulnerabilities. Run on a dedicated Vultr VM, keep images and the host patched, and use gVisor or per-task VMs for a stronger boundary. SHA-256 establishes output integrity, not that an AI-generated analysis is statistically correct.

## Test

```text
npm ci
npm test
npm run check
npm run test:browser
npm run test:sandbox
```

Browser tests use installed Microsoft Edge on Windows. Override `PLAYWRIGHT_BROWSER_EXECUTABLE` if necessary. On Linux install Chromium with `npx playwright install --with-deps chromium`. `test:sandbox` deliberately fails when Docker/resource enforcement/the image are absent; it never silently skips runtime validation.

## Submission materials

- [Project copy and checklist](docs/SUBMISSION.md)
- [Video recording script](docs/DEMO.md)
- [Presentation](public/slides.html), served at `/slides`; print it to PDF
- `docs/presentation.pdf`, generated by the browser export check
- `public/cover.png`, generated from the original vector `public/cover.svg`
- [Containment and limitations](docs/SECURITY.md)

## Project layout

```text
public/       Website, original vector assets, presentation
server/       HTTP app, CSV validation, inference, jobs, sandbox adapter
sandbox/      Trusted image and bounded Python runner
data/         Bundled sample CSV
deploy/       Rootless-user service and HTTPS reverse proxy examples
docs/         Deployment and submission materials
test/         Backend, HTTP, browser, and real-Docker tests
```

Original project source and artwork are MIT-licensed. Python dependencies retain their own upstream licenses; using MIT for this project's source does not relicense them. Confirm the organizer's precise meaning of "MIT-compliant" before submission.
